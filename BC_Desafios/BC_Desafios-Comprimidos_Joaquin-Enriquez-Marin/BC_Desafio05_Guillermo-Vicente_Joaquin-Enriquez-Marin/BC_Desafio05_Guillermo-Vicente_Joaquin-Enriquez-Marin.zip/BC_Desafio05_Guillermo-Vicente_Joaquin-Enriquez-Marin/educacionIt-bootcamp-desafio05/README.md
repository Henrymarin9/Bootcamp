
# Bootcamp Full Stack Engineer > educaciónIT

## Entrega Desafío Grupal

## BC_Desafio05_Joquín-Enriquez-Marin_Guillermo-Vicente

### Authors

- [Joaquin Enriquez Marin](https://github.com/Henrymarin9)

- [Guillermo Vicente](https://github.com/gvicenteprieto)

### Tech Stack

**Node.js® :** <https://nodejs.org/>

**Sass:**      <https://sass-lang.com/>

### Run Locally

- Clone the project
- Go to the project directory
- Install dependencies

```bash
  npm install -g sass
```

#### Usage/Example Sass

sass --watch scr/styles.sass:public/styles.css
