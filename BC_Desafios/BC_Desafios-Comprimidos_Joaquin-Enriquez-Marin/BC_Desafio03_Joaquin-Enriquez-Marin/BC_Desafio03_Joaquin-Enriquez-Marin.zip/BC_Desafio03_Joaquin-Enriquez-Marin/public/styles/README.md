

| Item | Scope | URL |
| :-- | :---: | :--- |
| Iconos | Iconos UI | [ SVG Repo ](https://www.svgrepo.com/collection/social-and-company-colored-logo-icons/) |